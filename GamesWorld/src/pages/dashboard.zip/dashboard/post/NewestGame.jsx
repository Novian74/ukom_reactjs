// import { useState } from "react";
// import CreatePost from "./CreatePost";
// import DataTable from "datatables.net-dt";

export default function NewestGame() {
  return (
    <>
      {/* Page Content */}
      <div className="container-fluid">
        {/* page heading */}
        <div className="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 className="h3 mb-0 text-light">Newest Game</h1>
        </div>

      </div>
      <div className="card-body mt-5">
        <div className="table-responsive">
          <table
            className="table text-center text-light table-dark mt-3"
            id="dataTable"
            // width="50%"
          >
            <thead>
              <tr>
                <th>ID</th>
                <th>Nama Game</th>
                <th>Genre</th>
                <th>Tanggal Upload</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td>Counter Strike</td>
                <td>FPS</td>
                <td>04-10-2023</td>
              </tr>
              <tr>
                <td>2</td>
                <td>Lost Saga: Origin</td>
                <td>RPG</td>
                <td>10-05-2020</td>
              </tr>
              <tr>
                <td>3</td>
                <td>Point Blank</td>
                <td>FPS</td>
                <td>04-10-2022</td>
              </tr>

              <tr>
                <td>4</td>
                <td>OverWatch 2</td>
                <td>FPS</td>
                <td>04-10-2022</td>
              </tr>
              <tr>
                <td>5</td>
                <td>NFS Heat</td>
                <td>FPS</td>
                <td>04-10-2022</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
