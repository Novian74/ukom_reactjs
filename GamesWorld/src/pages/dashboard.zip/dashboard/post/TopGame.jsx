// import { useState } from "react";
// import CreatePost from "./CreatePost";
// import DataTable from "datatables.net-dt";

export default function TopGame() {
  return (
    <>
      {/* Page Content */}
      <div className="container-fluid">
        {/* page heading */}
        <div className="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 className="h3 mb-0 text-light">Top Game</h1>
        </div>

        {/* <div
          style={{ backgroundColor: "#1e1e2f" }}
          className="card shadow mb-4"> */}
        {/* <div
            style={{ backgroundColor: "#1e1e2f" }}
            className="card-header py-3"> */}
      </div>
      <div className="card-body mt-5">
        <div className="table-responsive">
          <table
            className="table text-center text-light table-dark mt-3"
            id="dataTable"
            // width="50%"
          >
            <thead>
              <tr>
                <th>ID</th>
                <th>Nama Game</th>
                <th>Genre</th>
                <th>Tanggal Upload</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td>Apex Legend</td>
                <td>FPS</td>
                <td>04-10-2023</td>
              </tr>
              <tr>
                <td>2</td>
                <td>Call Of Duty: Modern Warfare</td>
                <td>FPS</td>
                <td>10-05-2020</td>
              </tr>
              <tr>
                <td>3</td>
                <td>Counter Strike 2</td>
                <td>FPS</td>
                <td>04-10-2022</td>
              </tr>

              <tr>
                <td>4</td>
                <td>Valorant</td>
                <td>FPS</td>
                <td>04-10-2022</td>
              </tr>
              <tr>
                <td>5</td>
                <td>Player Unknown Battle Ground</td>
                <td>FPS</td>
                <td>04-10-2022</td>
              </tr>
              <tr>
                <td>6</td>
                <td>Pamali</td>
                <td>Horror</td>
                <td>04-10-2022</td>
              </tr>
              <tr>
                <td>7</td>
                <td>Escape from Naraka</td>
                <td>Horror Platformer</td>
                <td>04-10-2022</td>
              </tr>
              <tr>
                <td>8</td>
                <td>Need For Speed</td>
                <td>Racing</td>
                <td>04-10-2022</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      {/* </div> */}
      {/* </div> */}
    </>
  );
}
