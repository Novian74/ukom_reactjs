import Sidebar from "../layouts/Sidebar";
import Topbar from "../layouts/Topbar";
export default function AddGame() {
  return (
    <div style={{ backgroundColor: "#1e1e2f" }} id="wrapper">
      {/* Sidebar */}
      <Sidebar />

      {/* Content Wrapper  */}
      <div
        id="content-wrapper"
        className="d-flex flex-column"
        style={{ backgroundColor: "#1e1e2f" }}>
        {/* Main Content  */}
        <div id="content">
          {/* Topbar  */}
          <Topbar />
          {/* End of Topbar  */}

          <div className="container-fluid">
            <div className="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 className="h3 mb-0 text-light">Add Game</h1>
            </div>
            <div className="col"></div>
            <form className="text-white">
              {/* Game Name */}
              <div className="form-group">
                <label>Game Name :</label>
                <input
                  type="text"
                  className="form-control text-white "
                  style={{ background: "#27293d" }}></input>
              </div>
              <div className="form-group">
                <label>Game Category :</label>
                <input
                  type="text"
                  className="form-control text-white "
                  style={{ background: "#27293d" }}></input>
              </div>
              <div className="form-group">
                <label>Game Release :</label>
                <input
                  type="text"
                  className="form-control text-white "
                  style={{ background: "#27293d" }}></input>
              </div>
              <div className="form-group">
                <label>Game Desc :</label>
                <textarea
                  className="form-control"
                  id="exampleFormControlTextarea1"
                  rows="3"
                  style={{ background: "#27293d" }}></textarea>
              </div>

              {/* Upload File */}
              <div className="form-group">
                <label>Game Picture :</label>
                <input
                  type="file"
                  accept=".jpg, .png, .jpeg"
                  className="form-control text-white "
                  style={{ background: "#27293d" }}></input>
              </div>
              <div className="form-group">
                <label>Game Preview :</label>
                <input
                  type="file"
                  accept=".jpg, .png, .jpeg"
                  className="form-control text-white "
                  style={{ background: "#27293d" }}></input>
                <input
                  type="file"
                  accept=".jpg, .png, .jpeg"
                  className="form-control text-white mt-3"
                  style={{ background: "#27293d" }}></input>
                <input
                  type="file"
                  accept=".jpg, .png, .jpeg"
                  className="form-control text-white mt-3"
                  style={{ background: "#27293d" }}></input>
              </div>
              <div>
                {/* Akan ditampilkan ketika admin setelah upload gambar */}
                {/* <div className="row">
                  <div className="col-md-3">Preview 1</div>
                  <div className="col-md-3">Preview 2</div>
                  <div className="col-md-3">Preview 3</div>
                  <div className="col-md-3">Preview 4</div>
                </div> */}
              </div>

              <hr className="mt-5" />

              {/* FORM ABOUT */}

              {/* About 1 */}
              <h4 className="mb-5">ABOUT GAME</h4>
              <div className="row mb-4">
                <div className="col-md-4 form-group">
                  <label>Title1</label>
                  <input
                    type="text"
                    className="form-control text-white "
                    style={{ background: "#27293d" }}></input>
                </div>
                <div className="col-md-4 form-group">
                  <label>Subtitle1</label>
                  <input
                    type="text"
                    className="form-control text-white "
                    style={{ background: "#27293d" }}></input>
                </div>
                <div className="col form-group">
                  <label>Gambar1</label>
                  <input
                    type="file"
                    accept=".jpg, .png, .jpeg"
                    className="form-control text-white "
                    style={{ background: "#27293d" }}></input>
                </div>

                <div className="col-md-8 form-group">
                  <label>Deskripsi1</label>
                  <textarea
                    type="text"
                    className="form-control text-white "
                    style={{ background: "#27293d" }}></textarea>
                </div>
                <div className="row">
                  {/* jika kondisi state img sudah ada isinya maka akan muncul tulisan preview dan gambar yang diupload*/}
                  <div className="col-md-4">Preview : </div>
                </div>
              </div>
              {/* About 2 */}
              <div className="row mb-5">
                <div className="col-md-4 form-group">
                  <label>Title 2</label>
                  <input
                    type="text"
                    className="form-control text-white "
                    style={{ background: "#27293d" }}></input>
                </div>
                <div className="col-md-4 form-group">
                  <label>Subtitle 2</label>
                  <input
                    type="text"
                    className="form-control text-white "
                    style={{ background: "#27293d" }}></input>
                </div>
                <div className="col form-group">
                  <label>Gambar 2</label>
                  <input
                    type="file"
                    accept=".jpg, .png, .jpeg"
                    className="form-control text-white "
                    style={{ background: "#27293d" }}></input>
                </div>
                <div className="col-md-8 form-group">
                  <label>Deskripsi 2</label>
                  <textarea
                    type="text"
                    className="form-control text-white "
                    style={{ background: "#27293d" }}></textarea>
                </div>
                <div className="row">
                  {/* jika kondisi state img sudah ada isinya maka akan muncul tulisan preview dan gambar yang diupload*/}
                  <div className="col-md-4">Preview : </div>
                </div>
              </div>
              {/* About 3 */}

              <div className="row mb-5">
                <div className="col-md-4 form-group">
                  <label>Title 3</label>
                  <input
                    type="text"
                    className="form-control text-white "
                    style={{ background: "#27293d" }}></input>
                </div>
                <div className="col-md-4 form-group">
                  <label>Subtitle 3</label>
                  <input
                    type="text"
                    className="form-control text-white "
                    style={{ background: "#27293d" }}></input>
                </div>
                <div className="col form-group">
                  <label>Gambar 3</label>
                  <input
                    type="file"
                    accept=".jpg, .png, .jpeg"
                    className="form-control text-white "
                    style={{ background: "#27293d" }}></input>
                </div>
                <div className="col-md-8 form-group">
                  <label>Deskripsi 3</label>
                  <textarea
                    type="text"
                    className="form-control text-white "
                    style={{ background: "#27293d" }}></textarea>
                </div>
                <div className="row">
                  {/* jika kondisi state img sudah ada isinya maka akan muncul tulisan preview dan gambar yang diupload*/}
                  <div className="col-md-4">Preview : </div>
                </div>
              </div>

              {/* About 4 */}
              <div className="row mb-5">
                <div className="col-md-4 form-group">
                  <label>Title 4</label>
                  <input
                    type="text"
                    className="form-control text-white "
                    style={{ background: "#27293d" }}></input>
                </div>
                <div className="col-md-4 form-group">
                  <label>Subtitle 4</label>
                  <input
                    type="text"
                    className="form-control text-white "
                    style={{ background: "#27293d" }}></input>
                </div>
                <div className="col form-group">
                  <label>Gambar 4</label>
                  <input
                    type="file"
                    accept=".jpg, .png, .jpeg"
                    className="form-control text-white "
                    style={{ background: "#27293d" }}></input>
                </div>
                <div className="col-md-8 form-group">
                  <label>Deskripsi 4</label>
                  <textarea
                    type="text"
                    className="form-control text-white "
                    style={{ background: "#27293d" }}></textarea>
                </div>
                <div className="row">
                  {/* jika kondisi state img sudah ada isinya maka akan muncul tulisan preview dan gambar yang diupload*/}
                  <div className="col-md-4">Preview : </div>
                </div>
              </div>
              {/* End Form About */}

              <hr />

              <div className="form-group">
                <h4>Minimum Specification :</h4>
                <div className="row">
                  <div className="col-md-6">
                    <label htmlFor="leftInput" className="col-form-label">
                      CPU :
                    </label>
                    <input
                      type="text"
                      className="form-control text-white"
                      style={{ background: "#27293d" }}
                      id="leftInput"
                    />
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="leftInput" className="col-form-label">
                      GPU :
                    </label>
                    <input
                      type="text"
                      className="form-control text-white"
                      style={{ background: "#27293d" }}
                      id="rightInput"
                    />
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-6">
                    <label htmlFor="leftInput" className="col-form-label">
                      RAM :
                    </label>
                    <input
                      type="text"
                      className="form-control text-white"
                      style={{ background: "#27293d" }}
                      id="leftInput"
                    />
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="leftInput" className="col-form-label">
                      Hardisk :
                    </label>
                    <input
                      type="text"
                      className="form-control text-white"
                      style={{ background: "#27293d" }}
                      id="rightInput"
                    />
                  </div>
                    <div className="col-md-6 mx-auto text-center mt-2">
                      <div>
                        <label htmlFor="leftInput" className="form-label">
                          OS :
                        </label>
                        <input
                          type="text"
                          className="form-control text-white"
                          style={{ background: "#27293d" }}
                          id="leftInput"
                        />
                      </div>
                    </div>
                </div>
              </div>
              <div className="form-group">
                <h4>Recomended Specification :</h4>
                <div className="row">
                  <div className="col-md-6">
                    <label htmlFor="leftInput" className="col-form-label">
                      CPU :
                    </label>
                    <input
                      type="text"
                      className="form-control text-white"
                      style={{ background: "#27293d" }}
                      id="leftInput"
                    />
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="leftInput" className="col-form-label">
                      GPU :
                    </label>
                    <input
                      type="text"
                      className="form-control text-white"
                      style={{ background: "#27293d" }}
                      id="rightInput"
                    />
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-6">
                    <label htmlFor="leftInput" className="col-form-label">
                      RAM :
                    </label>
                    <input
                      type="text"
                      className="form-control text-white"
                      style={{ background: "#27293d" }}
                      id="leftInput"
                    />
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="leftInput" className="col-form-label">
                      Hardisk :
                    </label>
                    <input
                      type="text"
                      className="form-control text-white"
                      style={{ background: "#27293d" }}
                      id="rightInput"
                    />
                  </div>
                    <div className="col-md-6 mx-auto text-center mt-2">
                      <div>
                        <label htmlFor="leftInput" className="form-label">
                          OS :
                        </label>
                        <input
                          type="text"
                          className="form-control text-white"
                          style={{ background: "#27293d" }}
                          id="leftInput"
                        />
                      </div>
                    </div>
                </div>
                <hr />
              </div>

              <div>
                <button type="button" className="btn btn-outline-success my-2 mx-2">
                  Add
                </button>
                <button type="button" className="btn btn-outline-danger my-2 mx-2">
                  Cancel
                </button>
              </div>
            </form>
          </div>

          {/* {showDashboard && <Dashboard />}
            {showAddGame && <AddGame />}
            {showEditGame && <EditGame />}
            {showPost && (
              <GameList
                handleAddGameClick={handleAddGameClick}
                handleEditGameClick={handleEditGameClick}
              />
            )}
            {showCategories && <UserComment />}
            {showUsers && <Users />} */}
        </div>
        {/* End of Main Content  */}

        {/* Footer  */}
        <footer
          style={{ backgroundColor: "#1e1e2f" }}
          className="sticky-footer">
          <div className="container my-auto">
            <div className="copyright text-center my-auto">
              <span>Copyright &copy; Your Website 2021</span>
            </div>
          </div>
        </footer>
        {/* End of Footer */}
      </div>
      {/* End of Content Wrapper  */}
    </div>
  );
}
